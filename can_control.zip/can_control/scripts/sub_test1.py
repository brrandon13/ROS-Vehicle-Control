#!/usr/bin/env python3

from novatel_oem7_msgs.msg import BESTPOS, CORRIMU, BESTVEL, HEADING2
import rospy
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from geopy import distance

steer=[]
cur_yaw=[]
tar_vel=[]
tar_yaw=[]
tar_x=[]
tar_y=[]
cur_x=[]
cur_y=[]
time = []
error1=[]
error2=[]
index = 0
idx=0
pos_idx =[]
check = False

def pos_callback(data):
    global lat , lon, cur_x, cur_y, pos_idx, idx
    pos_idx.append(idx)
    idx += 1
    lat= data.lat
    lon= data.lon
    cur_x.append(lat)
    cur_y.append(lon)
    check_finish()    

def head_callback(data):
    global yaw, cur_yaw
    yaw = data.heading
    cur_yaw.append(yaw)    
    
def check_finish():
    global lat, lon, yaw,index, tar_x, tar_y,check
    finish = len(tar_x)
    if check == False:
        if distance.distance((lat,lon),(tar_x[index],tar_y[index])) <= 0.02:
            index +=1
            print(index, finish)
            
            if index>= 225:#finish:
                make_plot()

def make_plot():
    global check
    check = True
    print("finish")
    global cur_x, cur_y, tar_x, tar_y, pos_idx
    # plt.figure(1)
    print('pos_idx', len(pos_idx))
    print('yaw', len(tar_yaw))

    plt.subplot(311)
    plt.plot(cur_x,label="lat")
    plt.subplot(312)
    plt.plot(cur_y,label="lon")
    plt.subplot(313)
    plt.plot(cur_yaw,label='yaw')
    plt.savefig('./test1.png', dpi=300)
    plt.figure(2)
    plt.subplot(211)
    plt.plot(cur_x,cur_y,label="path")
    plt.subplot(212)
    plt.plot(cur_x,cur_y,tar_x,tar_y,'r-')
    plt.savefig('./test2.png', dpi=300)
    print("fi")

def main():
    rospy.init_node('listener',anonymous=True)
    rospy.Subscriber("novatel/oem7/heading2",HEADING2,head_callback)
    rospy.Subscriber("novatel/oem7/bestpos",BESTPOS,pos_callback)
    rospy.spin()

    
if __name__ == '__main__':
    Waypoints = pd.read_csv('/home/nvidia/xavierworkspace/th_catkin_ws/src/hs_car/script/Waypoints2.csv',encoding='utf-8')
    temp = pd.DataFrame(Waypoints)

    for i in range(0,238) :
        t_lat= temp.at[i,'lat']
        t_lon= temp.at[i,'lon']
        t_speed= temp.at[i,'speed']
        tar_x.append(t_lat)
        tar_y.append(t_lon)
        tar_vel.append(t_speed)

    for i in range(1,238) :
        tar_yaw.append(180/np.pi*np.arctan2(tar_x[i]-tar_x[i-1],tar_y[i]-[i-1]))

    main()
